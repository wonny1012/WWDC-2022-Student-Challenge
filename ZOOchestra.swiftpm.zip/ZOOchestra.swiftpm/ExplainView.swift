//
//  File.swift
//  WWDC_Wonny
//
//  Created by kwon ji won on 2022/04/22.
//

import SwiftUI

struct ExplainView: View {
    @Binding var firstNaviLinkActive: Bool
    var body: some View {
        Text("Hello, world!")
            .padding()
    }
}
